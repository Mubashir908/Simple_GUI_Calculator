Simple GUI calculator built Java Swing which can easily perform basic calculations like multiplication, Division
, Subtraction, Addition.