import javax.swing.*;
public class CalculatorMain {
public static void main(String[]args) {
	Calculator calc=new Calculator();
	calc.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	calc.setSize(200,250);
	calc.setVisible(true);
}
}
