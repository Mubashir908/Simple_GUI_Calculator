import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class Calculator extends JFrame {
private JButton one;
private JButton two;
private JButton three;
private JButton four;
private JButton five;
private JButton six;
private JButton seven;
private JButton eight;
private JButton nine;
private JButton plus;
private JButton minus;
private JButton mult;
private JButton divide;
private JButton equalto;
private JButton clear;
private JButton point;
private JButton zero;
private JLabel credit;
private JTextField screen;
private ButtonGroup grp;
static String scr="";
private int pl=0;
private int min=0;
private int mul=0;
private int divd=0;
public  double var1;
public  double var2;
public  double Result;
public Calculator() {
	super("MBAM Calc");
	setLayout(new FlowLayout());
	screen=new JTextField("",15);
	add(screen);
	zero=new JButton("0");
	add(zero);
	one=new JButton("1");
	add(one);
	two=new JButton("2");
	add(two);
	three=new JButton("3");
	add(three);
	four=new JButton("4");
	add(four);
	five=new JButton("5");
	add(five);
	six=new JButton("6");
	add(six);
	seven=new JButton("7");
	add(seven);
	eight=new JButton("8");
	add(eight);
	nine=new JButton("9");
	add(nine);
	plus=new JButton("+");
	add(plus);
	minus=new JButton("-");
	add(minus);
	mult=new JButton("X");
	add(mult);
	divide=new JButton("/");
	add(divide);
	
	grp=new ButtonGroup();
	grp.add(plus);
	grp.add(minus);
	grp.add(mult);
	grp.add(divide);
	clear=new JButton("C");
	add(clear);
	
	point=new JButton(".");
	add(point);
	equalto=new JButton("=");
	add(equalto);
	credit=new JLabel("Designed by Mubashir Ul Hassan");
	credit.setFont(new Font("Arial",Font.BOLD,12));
	credit.setForeground(Color.RED);
	add(credit);
	//Actions of Buttons
	//Zero Button.
		zero.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				scr+="0";
				if(event.getSource()==zero)
					screen.setText(scr);
			}
		});;
	//one Button.
	one.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent event) {
			scr+="1";
			if(event.getSource()==one)
				screen.setText(scr);
		}
	});;
	//Two Button.
	two.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent event) {
			scr+="2";
			if(event.getSource()==two)
				screen.setText(scr);
		}
	});;
	//Three Button.
		three.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				scr+="3";
				if(event.getSource()==three)
					screen.setText(scr);
			}
		});;
		//Four Button.
				four.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent event) {
						scr+="4";
						if(event.getSource()==four)
							screen.setText(scr);
					}
			});;
		//Five Button.
			five.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent event) {
					scr+="5";
					if(event.getSource()==five)
						screen.setText(scr);
				}
		});;
		//Six Button.
		six.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				scr+="6";
				if(event.getSource()==six)
					screen.setText(scr);
			}
	});;
	//Seven Button.
			seven.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent event) {
					scr+="7";
					if(event.getSource()==seven)
						screen.setText(scr);
				}
		});;
	//Eight Button	
		eight.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				scr+="8";
				if(event.getSource()==eight)
					screen.setText(scr);
			}
	});;
	//Nine Button	
			nine.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent event) {
					scr+="9";
					if(event.getSource()==nine)
						screen.setText(scr);
				}
		});;
		//Plus Button	
				plus.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent event) {
						if(var1==0) {
						if(event.getSource()==plus) {
					  var1=Double.parseDouble(scr);
						scr="";
						screen.setText(scr);
						pl++;
						}
						}
						else {
							var2=Double.parseDouble(scr);
							scr="";
							screen.setText(scr);
							
							
				            Result=var1+var2;
						
							scr=String.format("%f", Result);
							
							screen.setText(scr);
							var2=0;
							var1=0;
						}
						
					}
			});;
			//Minus Button	
			minus.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent event) {
					if(var1==0) {
					if(event.getSource()==minus) {
				  var1=Double.parseDouble(scr);
					scr="";
					screen.setText(scr);
					 min++;
					}
					}
					else {
						var2=Double.parseDouble(scr);
						scr="";
						screen.setText(scr);
						
			            Result=var1-var2;
					
						scr=String.format("%f", Result);
						
						screen.setText(scr);
						var2=0;
						var1=0;
					}
					
				}
		});;
		//Multiply Button	
		mult.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				if(var1==0) {
				if(event.getSource()==mult) {
			  var1=Double.parseDouble(scr);
				scr="";
				screen.setText(scr);
				 mul++;
				}
				}
				else {
					var2=Double.parseDouble(scr);
					scr="";
					screen.setText(scr);
					
		            Result=var1*var2;
				
					scr=String.format("%f", Result);
					
					screen.setText(scr);
					var2=0;
					var1=0;
				}
				
			}
	});;
	//Divide Button	
	divide.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent event) {
			if(var1==0) {
			if(event.getSource()==divide) {
		  var1=Double.parseDouble(scr);
			scr="";
			screen.setText(scr);
			 min++;
			}
			}
			else {
				var2=Double.parseDouble(scr);
				scr="";
				screen.setText(scr);
				
	            Result=var1/var2;
			
				scr=String.format("%f", Result);
				
				screen.setText(scr);
				var2=0;
				var1=0;
			}
			
		}
});;
	//Point Button.
		point.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				scr+=".";
				if(event.getSource()==point)
					screen.setText(scr);
			}
	});;
	//Equals Button
		equalto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				if(event.getSource()==equalto) {
					if(pl>0) {
						var2=Double.parseDouble(scr);
						Result=var1+var2;
						scr=String.format("%f", Result);
						screen.setText(scr);
						var1=0;
						var2=0;
						
					}
					else if(min>0) {
						var2=Double.parseDouble(scr);
						Result=var1-var2;
						scr=String.format("%f", Result);
						screen.setText(scr);
						var2=0;
						var1=0;
					}
					else if(divd>0) {
						var2=Double.parseDouble(scr);
						Result=var1/var2;
						scr=String.format("%f", Result);
						screen.setText(scr);
						var2=0;
						var1=0;
					}
					else  {
						var2=Double.parseDouble(scr);
						Result=var1*var2;
						scr=String.format("%f", Result);
						screen.setText(scr);
						var2=0;
						var1=0;
					}
					
				}
					
			}
		});
		//Clear Button
		clear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				if (event.getSource()==clear) {
				scr="";
				screen.setText(scr);
				var1=0;
				var2=0;
				Result=0;
				}
			}
		});
}
}
